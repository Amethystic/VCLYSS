# VCLYSS
Voice Chat plugin for Atlyss multiplayer. (In Private Testing)
- Dont reveal this outside of the discord server
- But please do invite people into it, we dont want no incoming issues that will interfere with the testing phase
  https://discord.gg/ePhX4Fb2we