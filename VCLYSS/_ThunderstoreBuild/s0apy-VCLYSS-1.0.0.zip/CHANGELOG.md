# Changelog
<details><summary>Updates</summary>

## 1.0.0
- Initial release
</details>



<details><summary>Mini Updates</summary>

## BETA
- Join discord to see beta changelogs
</details>