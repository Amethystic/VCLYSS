# Changelog

<details><summary>Updates</summary>

## 1.0.0 - BETA
- Initial release

</details>

<details><summary>Mini Updates</summary>

## -
- shh, I branched off HAC

</details>