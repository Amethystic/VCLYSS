# Changelog

## 1.0.2 - Public Test Update
- Airborne check is back
- Fixed bugs

## 1.0.1 - Public Test Update
- Pushed

## 1.0.0

- Initial release